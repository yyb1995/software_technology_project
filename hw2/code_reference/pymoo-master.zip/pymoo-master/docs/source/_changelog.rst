**0.2.2**

- Several improvements in the code structure
- Make the cython support optional
- Modifications for pymop 0.2.3


**0.2.1**

- First official release providing NSGA2, NSGA3 and RNSGA3

