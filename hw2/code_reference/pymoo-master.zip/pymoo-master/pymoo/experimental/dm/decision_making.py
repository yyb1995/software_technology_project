class DecisionMaking:

    def do(self, X, F):
        pass


