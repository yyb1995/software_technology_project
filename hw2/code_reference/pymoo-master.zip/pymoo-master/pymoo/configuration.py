from pymoo.rand.impl.numpy_random_generator import NumpyRandomGenerator


class Configuration:
    rand = NumpyRandomGenerator()


